package com.premier.battlecoor;

public class Vote {
}
