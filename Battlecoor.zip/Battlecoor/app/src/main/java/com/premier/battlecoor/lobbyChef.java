package com.premier.battlecoor;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;


public class lobbyChef extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.lobby_chef);

        Button m1 = findViewById(R.id.exclure1);
        TextView p1 = findViewById(R.id.pseudo1);

        Button m2 = findViewById(R.id.exclure2);
        TextView p2 = findViewById(R.id.pseudo2);
        Button q = findViewById(R.id.quitter);

        p1.setText(Joueur.membre1);
        if(Joueur.libre1){
            m1.setVisibility(View.INVISIBLE);
        }

        p2.setText(Joueur.membre2);
        if(Joueur.libre2){
            m2.setVisibility(View.INVISIBLE);
        }

        class Commencer implements Runnable{
            private String[] rep;
            @Override
            public void run() {
                try{
                    InputStream in = Joueur.getSocket().getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    rep = reader.readLine().split(" ");

                    switch (rep[0]){
                        case "NOUVEAU_NUMERO":
                            Joueur.setNumChar(rep[1]);
                            startActivity(new Intent(lobbyChef.this, lobbyChef.class).addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION));
                            finish();
                            break;
                        case "START":
                            startActivity(new Intent(lobbyChef.this, Manette.class));
                            finish();
                            break;
                        case "KICK_EQUIPE":
                            startActivity(new Intent(lobbyChef.this, Formation.class));
                            finish();
                            break;
                        case "A_QUITTER":
                            Log.d("affichage", "reception de A_QUITTER");
                            if(Joueur.membre1.equals(rep[1])){
                                Joueur.libre1  = true;
                                Joueur.membre1 = "VIDE";
                            }else{
                                Joueur.libre2 = true;
                                Joueur.membre2 = "VIDE";
                            }
                            startActivity(new Intent(lobbyChef.this, lobbyChef.class).addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION));
                            finish();
                            break;
                        default://reception pseudo
                            if(Joueur.libre1){
                                Joueur.libre1 = false;
                                Joueur.membre1 = rep[0];
                            }else {
                                Joueur.libre2 = false;
                                Joueur.membre2 = rep[0];
                            }
                            startActivity(new Intent(lobbyChef.this, lobbyChef.class).addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION));
                            finish();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        Commencer commencer = new Commencer();
        final Thread C = new Thread(commencer);
        C.start();

        class Virer implements Runnable{
            @Override
            public void run() {
                try {
                    OutputStream out = Joueur.getSocket().getOutputStream();
                    PrintWriter writer = new PrintWriter(out);
                    writer.print(Joueur.getMessage());
                    writer.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        m1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Joueur.libre1) {
                    Joueur.libre1 = true;
                    Joueur.setMessage("KICK_EQUIPE " + Joueur.membre1);
                    Joueur.membre1 = "VIDE";
                    Virer virer = new Virer();
                    Thread t = new Thread(virer);
                    t.start();
                    try {
                        t.join();
                        startActivity(new Intent(lobbyChef.this, lobbyChef.class).addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION));
                        finish();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        m2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Joueur.libre2) {
                    Joueur.libre2 = true;

                    Joueur.setMessage("KICK_EQUIPE " + Joueur.membre2);
                    Joueur.membre2 = "VIDE";
                    Virer virer = new Virer();
                    Thread t = new Thread(virer);
                    t.start();
                    try {
                        t.join();
                        startActivity(new Intent(lobbyChef.this, lobbyChef.class).addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION));
                        finish();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        q.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EnvoieCommande message = new EnvoieCommande();

                try {
                    if(!Joueur.libre1){
                        Thread t = new Thread(message);
                        Joueur.setMessage("KICK_EQUIPE " + Joueur.membre1);
                        t.start();
                        t.join();
                    }
                    if(!Joueur.libre2){
                        Thread t = new Thread(message);
                        Joueur.setMessage("KICK_EQUIPE " + Joueur.membre2);
                        t.start();
                        t.join();
                    }
                    Thread t = new Thread(message);
                    Joueur.setMessage("QUITTER_EQUIPE");
                    t.start();
                    t.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Intent i = new Intent(lobbyChef.this, Formation.class);
                startActivity(i);
                finish();
            }
        });
    }
    @Override
    public void onBackPressed(){
    }
}
