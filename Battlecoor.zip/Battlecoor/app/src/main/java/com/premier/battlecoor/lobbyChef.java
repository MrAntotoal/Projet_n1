package com.premier.battlecoor;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.Window;
import android.widget.Button;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;


public class lobbyChef extends Activity {
    private String Membre1=null;
    private String Membre2=null;
    private boolean libre1=true; //emplacement 1 libre
    private boolean libre2=true;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.lobby_chef);

        final Button M1 = findViewById(R.id.exclure1);
        final Button M2 = findViewById(R.id.exclure2);
        Button Q = findViewById(R.id.quitter);


        class Commencer implements Runnable{
            String rep;
            boolean ok = false;
            @Override
            public void run() {
                try{
                    InputStream in = Joueur.getSocket().getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    rep = reader.readLine();
                    while (!ok){
                        if(rep.equals("START ") ){
                            ok = true;
                        }
                        else {
                            if (libre1) {
                                libre1 = false;
                                Membre1 = rep;
                                M1.setText(String.valueOf("Exclure " + Membre1));
                            } else {
                                libre2 = false;
                                Membre2 = rep;
                                M2.setText(String.valueOf("Exclure " + Membre2));
                            }
                            rep = reader.readLine();
                        }
                    }
                    startActivity(new Intent(lobbyChef.this, Manette.class));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        Commencer commencer = new Commencer();
        Thread t = new Thread(commencer);
        t.start();

        class Virer implements Runnable{
            @Override
            public void run() {
                try {
                    OutputStream out = Joueur.getSocket().getOutputStream();
                    PrintWriter writer = new PrintWriter(out);
                    writer.print(Joueur.getMessage());
                    writer.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        M1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!libre1) {
                    libre1 = true;
                    M1.setText("");
                    Joueur.setMessage("KICK_EQUIPE " + Membre1);
                    Virer virer = new Virer();
                    Thread t = new Thread(virer);
                    t.start();
                    try {
                        t.join();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        M2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!libre2) {
                    libre2 = true;
                    M2.setText("");
                    Joueur.setMessage("KICK_EQUIPE " + Membre2);
                    Virer virer = new Virer();
                    Thread t = new Thread(virer);
                    t.start();
                    try {
                        t.join();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        Q.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Joueur.setMessage("QUITTER_EQUIPE");
                EnvoieMessage message = new EnvoieMessage();
                Thread t = new Thread(message);
                t.start();
                try {
                    t.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Intent i = new Intent(lobbyChef.this, Formation.class);
                startActivity(i);
            }
        });
    }
    protected void onDestroy() {
        super.onDestroy();
        try {
            Joueur.fermerSocket();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed(){
    }
}
