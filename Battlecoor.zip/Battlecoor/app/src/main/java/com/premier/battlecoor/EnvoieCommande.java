package com.premier.battlecoor;

import android.util.Log;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;

class EnvoieCommande implements Runnable {
    @Override
    public void run() {
        try {
            OutputStream out = Joueur.getSocket().getOutputStream();
            PrintWriter writer = new PrintWriter(out);
            Log.d("affichage", "envoie de commande "+Joueur.getMessage());
            writer.print(Joueur.getMessage());
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
