package com.premier.battlecoor;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;

class EnvoieCommande implements Runnable {
    private String commande;

    EnvoieCommande(String cmd){
        commande = cmd;
    }

    @Override
    public void run() {
        try {
            OutputStream out = Joueur.getSocket().getOutputStream();
            PrintWriter writer = new PrintWriter(out);
                writer.println(commande);
                writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
