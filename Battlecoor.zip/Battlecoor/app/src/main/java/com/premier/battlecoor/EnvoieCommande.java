package com.premier.battlecoor;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;

public class EnvoieCommande implements Runnable {
    @Override
    public void run() {
        try {
            OutputStream out = Joueur.getSocket().getOutputStream();
            PrintWriter writer = new PrintWriter(out);
            writer.print(Joueur.getMessage());
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
