package com.premier.battlecoor;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

public class Pseudo extends Activity {

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.pseudo);


        Button Go = findViewById(R.id.button);
        final EditText nickname = findViewById(R.id.editText);


        Go.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                String pseudo;
                pseudo = nickname.getText().toString();
                if(pseudo.contains(" ")){
                    nickname.setText("");
                    nickname.setHintTextColor(getResources().getColor(R.color.rouge));
                    nickname.setHint("Pas d'espace");
                    return;
                }
                if(pseudo.length() == 0 || pseudo.length() >10){
                    nickname.setText("");
                    nickname.setHintTextColor(getResources().getColor(R.color.rouge));
                    nickname.setHint("Entre 1 et 10\ncaractères");
                    return;
                }

                CreationJoueur P = new CreationJoueur();
                Thread lp = new Thread(P);
                lp.start();
                try {
                    lp.join(2000);
                    if(Joueur.getSocket()==null){
                        startActivity(new Intent(Pseudo.this, ErreurConnexion.class));
                        finish();
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                Joueur.setMessage(pseudo);
                EnvoieMessage message = new EnvoieMessage();
                Thread t = new Thread(message);
                t.start();
                try {
                    t.join(2000);
                } catch (InterruptedException e) {
                    startActivity(new Intent(Pseudo.this, ErreurConnexion.class));
                    finish();
                }
                switch(Joueur.getReponse()){
                    case "MENU_JOUEUR":
                        Intent i;
                        i = new Intent(Pseudo.this, Formation.class);
                        startActivity(i);
                        finish();
                        break;
                    case "PSEUDO_POK":
                        nickname.setText("");
                        nickname.setHintTextColor(getResources().getColor(R.color.rouge));
                        nickname.setHint("Pseudo déjà existant");
                        break;
                }
            }
        });
    }
}
