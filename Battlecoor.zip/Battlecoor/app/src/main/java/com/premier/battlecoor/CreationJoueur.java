package com.premier.battlecoor;

import java.io.IOException;

class CreationJoueur implements Runnable {

    @Override
    public void run() {
        try {
            new Joueur();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
