package com.premier.battlecoor;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class lobbySoldat extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.lobby_soldat);

        Button Q = findViewById(R.id.quitter);


        class Commencer implements Runnable{
            private String[] rep;
            @Override
            public void run() {
                try{
                    InputStream in = Joueur.getSocket().getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    rep = reader.readLine().split(" ");
                    Log.d("affichage", "reception de "+rep[0]);
                    switch (rep[0]){
                        case "START":
                            startActivity(new Intent(lobbySoldat.this, Manette.class));
                            break;
                        case "KICK_EQUIPE"://le membre vient de se faire virer
                            startActivity(new Intent(lobbySoldat.this, Formation.class));
                            break;
                        case "NOUVEAU_NUMERO":
                            Joueur.setNumChar(rep[1]);
                            startActivity(new Intent(lobbySoldat.this, lobbySoldat.class).addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION));
                            finish();
                            break;
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        Commencer commencer = new Commencer();
        final Thread C = new Thread(commencer);
        C.start();

        Q.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EnvoieCommande message = new EnvoieCommande("QUITTER_EQUIPE");
                Thread t = new Thread(message);
                t.start();
                startActivity(new Intent(lobbySoldat.this, Formation.class));
                finish();
            }
        });

    }

    @Override
    public void onBackPressed(){
    }

}
