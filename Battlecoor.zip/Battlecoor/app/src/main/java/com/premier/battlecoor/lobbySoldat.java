package com.premier.battlecoor;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class lobbySoldat extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.lobby_soldat);

        Button Q = findViewById(R.id.quitter);


        class Commencer implements Runnable{
            String rep;
            @Override
            public void run() {
                try{
                    InputStream in = Joueur.getSocket().getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    rep = reader.readLine();
                    Log.d("affichage", "reception de "+rep);
                    switch (rep){
                        case "START ":
                            startActivity(new Intent(lobbySoldat.this, Manette.class));
                            break;
                        case "KICK_EQUIPE"://le membre vient de se faire virer
                            startActivity(new Intent(lobbySoldat.this, Formation.class));
                            break;
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        Commencer commencer = new Commencer();
        Thread t = new Thread(commencer);
        t.start();

        Q.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Joueur.setMessage("QUITTER_EQUIPE");
                EnvoieMessage message = new EnvoieMessage();
                Thread t = new Thread(message);
                t.start();
                try {
                    t.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                startActivity(new Intent(lobbySoldat.this, Formation.class));
            }
        });

    }

    @Override
    public void onBackPressed(){
    }

}
