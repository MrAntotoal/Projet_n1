package com.premier.battlecoor;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.Window;
import android.widget.Button;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Mort extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.mort);

        Button mort = findViewById(R.id.mort);

        mort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    finish();
                    System.exit(0);
                    Joueur.fermerSocket();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        Thread t  = new Thread(new Restart());
        t.start();
    }

    class Restart implements Runnable{
        String msg;

        @Override
        public void run() {
            try {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                v.vibrate(1000);
                InputStream in = Joueur.getSocket().getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                msg = reader.readLine();
                if(msg.equals("END")){
                    Joueur.setTousFalse();
                    startActivity(new Intent(Mort.this, Formation.class));
                    finish();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
    @Override
    public void onBackPressed(){
    }

}
