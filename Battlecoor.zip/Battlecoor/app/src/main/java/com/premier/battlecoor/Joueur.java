package com.premier.battlecoor;

import java.io.IOException;
import java.net.Socket;

// Cette classe est ok plus besoin de la modifer
class Joueur  {
    private static String ip = "192.168.1.124";


    static String /*pseudo,*/ membre1 = "VIDE", membre2="VIDE";
    static boolean libre1=true, libre2=true;
    private static String numChar;
    private static String mes;
    private static Socket s;
    private static String reponse; //reponse du serveur



    //Gestion des boutons
    static boolean GT = false;
    static boolean DT = false;
    static boolean HC = false;
    static boolean BC = false;
    static boolean GC = false;
    static boolean DC = false;
    static boolean GP = false;
    static boolean DP = false;
    static boolean P  =false;
    static boolean SP  =false;
    static boolean ST  =false;
    static boolean SC  =false;


    enum type {conducteur, tireur, protecteur}
    static type role;


    //Gestion chargement des bouttons
    static boolean ConducteurGauche = false;
    static boolean ConducteurDroite= false;
    static boolean ConducteurHautBas= false;
    static boolean ConducteurSpecial= false;
    static boolean TireurGauche= false;
    static boolean TireurDroite= false;
    static boolean Feu= false;
    static boolean TireurSpecial= false;
    static boolean ProtecteurGauche= false;
    static boolean ProtecteurDroite= false;
    static boolean Protection= false;
    static boolean ProtecteurSpecial= false;



    Joueur() throws IOException {
        int PORT = 1977;
        s = new Socket(ip, PORT);
    }

    static void sortirEquipe(){
        libre1 = true;libre2= true;
        membre1 = "VIDE";membre2="VIDE";
    }
      static void setNumChar(String num){
        numChar = num;
    }

      static String getNumChar(){
        return numChar;
    }

      static synchronized Socket getSocket(){
        return s;
    }

    public static void fermerSocket() throws IOException {
        s.close();
    }

      static void setReponse(String l){
        reponse = l;
    }
     static String getReponse(){
        return reponse;
    }

      static String getMessage(){
        return mes;
    }
    //A modifier avant d'envoyer un message
    static synchronized void setMessage(String message){
        mes = message;
    }

    static void setIp(String add){ip = add;}

    static void setRole(String papel){
        setTousFalse();
        switch (papel) {
            case "ROLE 0":
                role = type.conducteur;
                ConducteurDroite = true;
                ConducteurGauche = true;
                ConducteurHautBas = true;
                ConducteurSpecial = true;
                break;

            case "ROLE 1":
                //role = "Tireur";
                role = type.tireur;
                TireurDroite = true;
                TireurGauche = true;
                TireurSpecial = true;
                Feu = true;
                break;

            case "ROLE 2":
                //role = "Protecteur";
                role = type.protecteur;
                ProtecteurDroite = true;
                ProtecteurGauche = true;
                ProtecteurSpecial = true;
                Protection = true;
                break;
        }
    }
    public static void setTousFalse(){
        ConducteurGauche = false; ConducteurDroite= false; ConducteurHautBas= false; ConducteurSpecial= false;
        TireurGauche= false; TireurDroite= false; Feu= false; TireurSpecial= false;
        ProtecteurGauche= false; ProtecteurDroite= false; Protection= false; ProtecteurSpecial= false;
    }
}
