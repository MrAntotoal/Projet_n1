package com.premier.battlecoor;

import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.UnknownHostException;

class EnvoieMessage  implements Runnable{
    //Cette classe envoie un message au serveur et attent toujours une réponse du serveur

    @Override
    public void run() {
        try {
            /*Socket*/
            InputStream in = Joueur.getSocket().getInputStream();
            OutputStream out = Joueur.getSocket().getOutputStream();
            BufferedReader reader =new BufferedReader(new InputStreamReader(in));

            //envoie de la requête au serveur
            PrintWriter writer = new PrintWriter(out);
            writer.print(Joueur.getMessage());
            writer.flush();
            Log.d("affichage", "envoie de "+Joueur.getMessage());
            if(reader.ready()){
                Log.d("", "pret pour la lecture");
            }else{
                Log.d("", "NOT READY!!!");
            }
            //attente bloquante de la reponse su serveur
            Joueur.setReponse(reader.readLine());

            Log.d("affichage", "reception de "+Joueur.getReponse());


        }
        catch (UnknownHostException e1) {
            e1.printStackTrace();
        }
        catch (IOException e2){
            e2.printStackTrace();
        }

    }


}
