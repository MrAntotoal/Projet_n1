package com.premier.battlecoor;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.support.annotation.Nullable;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Manette extends Activity {
    private Button ConducteurGauche;
    private Button ConducteurDroite;
    private Button Haut;
    private Button Bas;
    private Button ConducteurSpecial;
    private Button TireurGauche;
    private Button TireurDroite;
    private Button Feu;
    private Button TireurSpecial;
    private Button ProtecteurGauche;
    private Button ProtecteurDroite;
    private Button Protection;
    private Button ProtecteurSpecial;
    private Button Fix;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.manette);

        //Conducteur
        ConducteurGauche = findViewById(R.id.CG);
        ConducteurDroite = findViewById(R.id.CD);
        Haut = findViewById(R.id.Haut);
        Bas = findViewById(R.id.Bas);
        ConducteurSpecial = findViewById(R.id.SC);

        //Tireur
        TireurGauche = findViewById(R.id.TG);
        TireurDroite = findViewById(R.id.TD);
        Feu = findViewById(R.id.FEU);
        TireurSpecial = findViewById(R.id.ST);

        //Protecteur
        ProtecteurGauche = findViewById(R.id.PG);
        ProtecteurDroite = findViewById(R.id.PD);
        Protection = findViewById(R.id.PROTECTION);
        ProtecteurSpecial = findViewById(R.id.SP);

        //Bouton de fixation
        Fix = findViewById(R.id.fix);

        //CHARGEMENT DES BOUTTONS
        chargerBouton();

        Thread att = new Thread(new Attente());
        att.start();

        Fix.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        Fix.setBackgroundResource(R.drawable.cle2_allume);
                        Thread f = new Thread(new EnvoieCommande("DEPLACEMENT "+Joueur.getNumChar()+" 0 0"));
                        f.start();
                    return true;
                    case MotionEvent.ACTION_UP:
                        Fix.setBackgroundResource(R.drawable.cle2);
                        return true;
                }
                return false;
            }
        });
        //ACTION A REALISER
        ConducteurGauche.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.GC) {
                            ConducteurGauche.setBackgroundResource(R.drawable.gauche_conducteur_allume);
                            Joueur.GC = true;
                            Thread tg = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " 4 1"));
                            tg.start();
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                        ConducteurGauche.setBackgroundResource(R.drawable.gauche_conducteur);
                        Joueur.GC = false;
                        Thread tsg = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " -4 0"));
                        tsg.start();
                        return true;
                }
                return false;
            }
        });

        ConducteurDroite.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.DC) {
                            ConducteurDroite.setBackgroundResource(R.drawable.droite_conducteur_allume);
                            Joueur.DC = true;
                            Thread tg = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " 3 1"));
                            tg.start();
                        }
                        return true;


                    case MotionEvent.ACTION_UP:
                        ConducteurDroite.setBackgroundResource(R.drawable.droite_conducteur);
                        Joueur.DC = false;
                        Thread tsg = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " -3 0"));
                        tsg.start();
                        return true;
                }
                return false;
            }
        });

        Haut.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.HC) {
                            Haut.setBackgroundResource(R.drawable.haut_conducteur_allume);
                            Joueur.HC = true;
                            Thread tg = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " 1 1"));
                            tg.start();
                        }
                        return true;


                    case MotionEvent.ACTION_UP:
                        Joueur.HC = false;
                        Haut.setBackgroundResource(R.drawable.haut_conducteur);
                        Thread tsg = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " -1 0"));
                        tsg.start();
                        return true;
                }
                return false;
            }
        });

        Bas.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.BC) {
                            Bas.setBackgroundResource(R.drawable.bas_conducteur_allume);
                            Joueur.BC = true;
                            Thread tg = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " 2 1"));
                            tg.start();
                        }
                        return true;


                    case MotionEvent.ACTION_UP:
                        Bas.setBackgroundResource(R.drawable.bas_conducteur);
                        Joueur.BC = false;
                        Thread tsg = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " -2 0"));
                        tsg.start();
                        return true;
                }
                return false;
            }
        });

        TireurGauche.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.GT) {
                            TireurGauche.setBackgroundResource(R.drawable.gauche_tirreur_allume);
                            Joueur.GT = true;
                            Thread tg = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " 6 1"));
                            tg.start();
                        }
                        return true;


                    case MotionEvent.ACTION_UP:
                        TireurGauche.setBackgroundResource(R.drawable.gauche_tirreur);
                        Joueur.GT = false;
                        Thread tsg = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " -6 0"));
                        tsg.start();
                        return true;
                }
                return false;
            }
        });

        TireurDroite.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.DT) {
                            TireurDroite.setBackgroundResource(R.drawable.droite_tirreur_allume);
                            Joueur.DT = true;
                            Thread tg = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " 5 1"));
                            tg.start();
                        }
                        return true;


                    case MotionEvent.ACTION_UP:
                        TireurDroite.setBackgroundResource(R.drawable.droite_tirreur);
                        Joueur.DT = false;
                        Thread tsg = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " -5 0"));
                        tsg.start();
                        return true;
                }
                return false;
            }
        });


        Feu.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        Feu.setBackgroundResource(R.drawable.tirer_tirreur);
                        Thread t = new Thread(new EnvoieCommande("TIRER " + Joueur.getNumChar() + " 0"));
                        t.start();
                        return true;


                    case MotionEvent.ACTION_UP:
                        Feu.setEnabled(false);
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Feu.setEnabled(true);
                                Feu.setBackgroundResource(R.drawable.tirer_tirreur_allume);
                            }
                        }, 2000);
                        return true;
                }
                return false;
            }
        });
        ProtecteurGauche.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.GP) {
                            ProtecteurGauche.setBackgroundResource(R.drawable.gauche_protecteur_allume);
                            Joueur.GP = true;
                            Thread tg = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " 8 1"));
                            tg.start();
                        }
                        return true;


                    case MotionEvent.ACTION_UP:
                        ProtecteurGauche.setBackgroundResource(R.drawable.gauche_protecteur);
                        Joueur.GP = false;
                        Thread tsg = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " -8 0"));
                        tsg.start();
                        return true;
                }
                return false;
            }
        });

        ProtecteurDroite.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.DP) {
                            ProtecteurDroite.setBackgroundResource(R.drawable.droite_protecteur_allume);
                            Joueur.DP = true;
                            Thread tg = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " 7 1"));
                            tg.start();
                        }
                        return true;


                    case MotionEvent.ACTION_UP:
                        ProtecteurDroite.setBackgroundResource(R.drawable.droite_protecteur);
                        Joueur.DP = false;
                        Thread tsg = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " -7 0"));
                        tsg.start();
                        return true;
                }
                return false;
            }
        });
        ConducteurSpecial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Joueur.SC) {
                    Joueur.SC = false;
                    ConducteurSpecial.setBackgroundResource(R.drawable.special_conducteur);
                    Thread t = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " 20 0"));
                    t.start();
                }
            }
        });


        TireurSpecial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Joueur.ST) {
                    Joueur.ST = false;
                    TireurSpecial.setBackgroundResource(R.drawable.special_tirreur);
                    Thread t = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " 21 0"));
                    t.start();
                }
            }
        });

        ProtecteurSpecial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Joueur.SP) {
                    Joueur.SP = false;
                    ProtecteurSpecial.setBackgroundResource(R.drawable.special_protecteur);
                    Thread t = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " 22 0"));
                    t.start();
                }
            }
        });

        Protection.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        if(!Joueur.P) {
                            Protection.setBackgroundResource(R.drawable.protection_protecteur_allume);
                            Joueur.P = true;
                            Thread P = new Thread(new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " 11 0"));
                            P.start();
                        }
                        return true;


                    case MotionEvent.ACTION_UP:
                        Protection.setBackgroundResource(R.drawable.protection_protecteur);
                        Joueur.P = false;
                        Thread SP = new Thread(new EnvoieCommande("DEPLACEMENT  "+ Joueur.getNumChar() +" 12 0"));
                        SP.start();
                        return true;
                }
                return false;
            }
        });
    }
    class Attente implements Runnable{
        String[] rep;
        @Override
        public void run() {
            try {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                InputStream in  = Joueur.getSocket().getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                String msg = reader.readLine();
                rep = msg.split(" ");
                //le joueur vient de mourir ou utime ready
                if(rep[0].equals("NEW_BUTT")){
                    v.vibrate(400);
                    reinit();//si jamais le changement de bouton vient lorsque le joueur est en train d'appuyer
                    for(String var: rep){
                        switch (var){
                            case "F":
                                Joueur.Feu = true;

                                Joueur.Protection = false;
                                Joueur.ConducteurHautBas = false;
                                break;

                            case "TG":
                                Joueur.TireurGauche = true;

                                Joueur.ConducteurGauche = false;
                                Joueur.ProtecteurGauche = false;
                                break;

                            case "TD":
                                Joueur.TireurDroite = true;

                                Joueur.ConducteurDroite = false;
                                Joueur.ProtecteurDroite = false;
                                break;

                            case "TS":
                                Joueur.role = Joueur.type.tireur;
                                Joueur.TireurSpecial = true;

                                Joueur.ConducteurSpecial = false;
                                Joueur.ProtecteurSpecial = false;
                                break;

                            case "P":
                                Joueur.Protection = true;

                                Joueur.Feu = false;
                                Joueur.ConducteurHautBas = false;
                                break;

                            case "PG":
                                Joueur.ProtecteurGauche = true;

                                Joueur.ConducteurGauche = false;
                                Joueur.TireurGauche = false;
                                break;

                            case "PD":
                                Joueur.ProtecteurDroite = true;

                                Joueur.ConducteurDroite = false;
                                Joueur.TireurDroite = false;
                                break;

                            case "PS":
                                Joueur.role = Joueur.type.protecteur;
                                Joueur.ProtecteurSpecial = true;

                                Joueur.TireurSpecial = false;
                                Joueur.ConducteurSpecial = false;
                                break;

                            case "AR":
                                Joueur.ConducteurHautBas = true;

                                Joueur.Feu = false;
                                Joueur.Protection = false;
                                break;

                            case "CG":
                                Joueur.ConducteurGauche = true;

                                Joueur.ProtecteurGauche = false;
                                Joueur.TireurGauche = false;
                                break;

                            case "CD":
                                Joueur.ConducteurDroite = true;

                                Joueur.TireurDroite = false;
                                Joueur.ProtecteurDroite = false;
                                break;

                            case "CS":
                                Joueur.role = Joueur.type.conducteur;
                                Joueur.ConducteurSpecial = true;

                                Joueur.TireurSpecial = false;
                                Joueur.ProtecteurSpecial =false;
                                break;
                        }
                    }

                }else
                    switch (rep[0]) {
                        case "MORT":
                            Joueur.sortirEquipe();
                            Joueur.setTousFalse();
                            startActivity(new Intent(Manette.this, Mort.class));
                            finish();
                            return;
                        case "END":
                            Joueur.sortirEquipe();
                            Joueur.setTousFalse();
                            startActivity(new Intent(Manette.this, Formation.class));
                            finish();
                            return;

                        case "TIREUR_PRET":
                            Joueur.ST = true;
                            break;

                        case "CONDUCTEUR_PRET":
                            Joueur.SC = true;
                            break;

                        case "BOUCLIER_PRET":
                            Joueur.SP = true;
                            break;
                    }
                startActivity(new Intent(Manette.this, Manette.class).addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION));
                finish();
            } catch (IOException e1) {
                e1.printStackTrace();
            }

        }
    }


    private void chargerBouton(){
        //Conducteur
        if(Joueur.ConducteurGauche)
            ConducteurGauche.setVisibility(View.VISIBLE);
        if(Joueur.ConducteurDroite)
            ConducteurDroite.setVisibility(View.VISIBLE);
        if(Joueur.ConducteurHautBas){
            Haut.setVisibility(View.VISIBLE);
            Bas.setVisibility(View.VISIBLE);
        }
        if(Joueur.ConducteurSpecial) {
            ConducteurSpecial.setVisibility(View.VISIBLE);
            if(Joueur.SC) ConducteurSpecial.setBackgroundResource(R.drawable.special_conducteur_allume);
        }

        //Tireur
        if(Joueur.TireurSpecial) {
            TireurSpecial.setVisibility(View.VISIBLE);
            if(Joueur.ST) TireurSpecial.setBackgroundResource(R.drawable.special_tirreur_allume);
        }
        if(Joueur.TireurGauche)
            TireurGauche.setVisibility(View.VISIBLE);
        if(Joueur.TireurDroite)
            TireurDroite.setVisibility(View.VISIBLE);
        if(Joueur.Feu)
            Feu.setVisibility(View.VISIBLE);

        //Protecteur
        if(Joueur.Protection)
            Protection.setVisibility(View.VISIBLE);
        if(Joueur.ProtecteurGauche)
            ProtecteurGauche.setVisibility(View.VISIBLE);
        if(Joueur.ProtecteurDroite)
            ProtecteurDroite.setVisibility(View.VISIBLE);
        if(Joueur.ProtecteurSpecial) {
            ProtecteurSpecial.setVisibility(View.VISIBLE);
            if(Joueur.SP) ProtecteurSpecial.setBackgroundResource(R.drawable.special_protecteur_allume);
        }
    }

    private void reinit(){//ajustement des requete si changement de manette alors que boutons enfoncé
        if(Joueur.DC) {
            Joueur.DC = false;
            EnvoieCommande SG = new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " -3 0");
            Thread tsg = new Thread(SG);
            tsg.start();
        }
        if (Joueur.GC){
            Joueur.GC = false;
            EnvoieCommande SG = new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " -4 0");
            Thread tsg = new Thread(SG);
            tsg.start();
        }
        if(Joueur.HC){
            Joueur.HC= false;
            EnvoieCommande SG = new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " -1 0");
            Thread tsg = new Thread(SG);
            tsg.start();
        }
        if(Joueur.BC){
            Joueur.BC= false;
            EnvoieCommande SG = new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " -2 0");
            Thread tsg = new Thread(SG);
            tsg.start();
        }
        if(Joueur.GP){
            Joueur.GP= false;
            EnvoieCommande SG = new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " -8 0");
            Thread tsg = new Thread(SG);
            tsg.start();
        }
        if(Joueur.DP){
            Joueur.DP= false;
            EnvoieCommande SG = new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " -7 0");
            Thread tsg = new Thread(SG);
            tsg.start();
        }
        if(Joueur.P){
            Joueur.P= false;
            Thread SP = new Thread(new EnvoieCommande("DEPLACEMENT  "+ Joueur.getNumChar() +" 12 0"));
            SP.start();
        }
        if(Joueur.DT){
            Joueur.DT= false;
            EnvoieCommande SG = new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " -5 0");
            Thread tsg = new Thread(SG);
            tsg.start();
        }
        if(Joueur.GT){
            Joueur.GT= false;
            EnvoieCommande SG = new EnvoieCommande("DEPLACEMENT " + Joueur.getNumChar() + " -6 0");
            Thread tsg = new Thread(SG);
            tsg.start();
        }
    }
    @Override
    public void onBackPressed(){
    }

}
