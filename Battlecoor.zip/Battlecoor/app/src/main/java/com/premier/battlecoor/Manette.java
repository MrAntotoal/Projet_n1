package com.premier.battlecoor;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Manette extends Activity {
    private Button ConducteurGauche;
    private Button ConducteurDroite;
    private Button Haut;
    private Button Bas;
    private Button ConducteurSpecial;
    private Button TireurGauche;
    private Button TireurDroite;
    private Button Feu;
    private Button TireurSpecial;
    private Button ProtecteurGauche;
    private Button ProtecteurDroite;
    private Button Protection;
    private Button ProtecteurSpecial;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.manette);

        //Conducteur
        ConducteurGauche = findViewById(R.id.CG);
        ConducteurDroite = findViewById(R.id.CD);
        Haut = findViewById(R.id.Haut);
        Bas = findViewById(R.id.Bas);
        ConducteurSpecial = findViewById(R.id.SC);

        //Tireur
        TireurGauche = findViewById(R.id.TG);
        TireurDroite = findViewById(R.id.TD);
        Feu = findViewById(R.id.FEU);
        TireurSpecial = findViewById(R.id.ST);

        //Protecteur
        ProtecteurGauche = findViewById(R.id.PG);
        ProtecteurDroite = findViewById(R.id.PD);
        Protection = findViewById(R.id.PROTECTION);
        ProtecteurSpecial = findViewById(R.id.SP);

        //CHARGEMENT DES BOUTTONS
        Log.d("affichage", "chargement des boutons");
        chargerBouton();

        Log.d("affichage", "démarage du thread");
        Thread att = new Thread(new Attente());
        att.start();
        Log.d("affichage", "thread lancé");

        //ACTION A REALISER
        ConducteurGauche.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.GC) {
                            ConducteurGauche.setBackgroundResource(R.drawable.gauche_conducteur_allume);
                            Joueur.GC = true;
                            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " 4 1");
                            EnvoieCommande G = new EnvoieCommande();
                            Thread tg = new Thread(G);
                            tg.start();
                            try {
                                tg.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        ConducteurGauche.setBackgroundResource(R.drawable.gauche_conducteur);
                        Joueur.GC = false;
                        Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -4 0");
                        EnvoieCommande SG = new EnvoieCommande();
                        Thread tsg = new Thread(SG);
                        tsg.start();
                        try {
                            tsg.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                }
                return false;
            }
        });

        ConducteurDroite.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.DC) {
                            ConducteurDroite.setBackgroundResource(R.drawable.droite_conducteur_allume);
                            Joueur.DC = true;
                            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " 3 1");
                            EnvoieCommande G = new EnvoieCommande();
                            Thread tg = new Thread(G);
                            tg.start();
                            try {
                                tg.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        ConducteurDroite.setBackgroundResource(R.drawable.droite_conducteur);
                        Joueur.DC = false;
                        Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -3 0");
                        EnvoieCommande SG = new EnvoieCommande();
                        Thread tsg = new Thread(SG);
                        tsg.start();
                        try {
                            tsg.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                }
                return false;
            }
        });

        Haut.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.HC) {
                            Haut.setBackgroundResource(R.drawable.haut_conducteur_allume);
                            Joueur.HC = true;
                            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " 1 1");
                            EnvoieCommande G = new EnvoieCommande();
                            Thread tg = new Thread(G);
                            tg.start();
                            try {
                                tg.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        Joueur.HC = false;
                        Haut.setBackgroundResource(R.drawable.haut_conducteur);
                        Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -1 0");
                        EnvoieCommande SG = new EnvoieCommande();
                        Thread tsg = new Thread(SG);
                        tsg.start();
                        try {
                            tsg.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                }
                return false;
            }
        });

        Bas.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.BC) {
                            Bas.setBackgroundResource(R.drawable.bas_conducteur_allume);
                            Joueur.BC = true;
                            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " 2 1");
                            EnvoieCommande G = new EnvoieCommande();
                            Thread tg = new Thread(G);
                            tg.start();
                            try {
                                tg.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        Bas.setBackgroundResource(R.drawable.bas_conducteur);
                        Joueur.BC = false;
                        Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -2 0");
                        EnvoieCommande SG = new EnvoieCommande();
                        Thread tsg = new Thread(SG);
                        tsg.start();
                        try {
                            tsg.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                }
                return false;
            }
        });

        TireurGauche.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.GT) {
                            TireurGauche.setBackgroundResource(R.drawable.gauche_tirreur_allume);
                            Joueur.GT = true;
                            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " 6 1");
                            EnvoieCommande G = new EnvoieCommande();
                            Thread tg = new Thread(G);
                            tg.start();
                            try {
                                tg.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        TireurGauche.setBackgroundResource(R.drawable.gauche_tirreur);
                        Joueur.GT = false;
                        Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -6 0");
                        EnvoieCommande SG = new EnvoieCommande();
                        Thread tsg = new Thread(SG);
                        tsg.start();
                        try {
                            tsg.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                }
                return false;
            }
        });

        TireurDroite.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.DT) {
                            TireurDroite.setBackgroundResource(R.drawable.droite_tirreur_allume);
                            Joueur.DT = true;
                            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " 5 1");
                            EnvoieCommande G = new EnvoieCommande();
                            Thread tg = new Thread(G);
                            tg.start();
                            try {
                                tg.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        TireurDroite.setBackgroundResource(R.drawable.droite_tirreur);
                        Joueur.DT = false;
                        Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -5 0");
                        EnvoieCommande SG = new EnvoieCommande();
                        Thread tsg = new Thread(SG);
                        tsg.start();
                        try {
                            tsg.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                }
                return false;
            }
        });


        Feu.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        Feu.setBackgroundResource(R.drawable.tirer_tirreur_allume);
                        Joueur.setMessage("TIR " + Joueur.getNumChar() + " 0");
                        EnvoieCommande tir = new EnvoieCommande();
                        Thread t = new Thread(tir);
                        t.start();
                        try {
                            t.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        Feu.setBackgroundResource(R.drawable.tirer_tirreur);
                        return true;
                }
                return false;
            }
        });
        ProtecteurGauche.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.GP) {
                            ProtecteurGauche.setBackgroundResource(R.drawable.gauche_protecteur_allume);
                            Joueur.GP = true;
                            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " 8 1");
                            EnvoieCommande G = new EnvoieCommande();
                            Thread tg = new Thread(G);
                            tg.start();
                            try {
                                tg.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        ProtecteurGauche.setBackgroundResource(R.drawable.gauche_protecteur);
                        Joueur.GP = false;
                        Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -8 0");
                        EnvoieCommande SG = new EnvoieCommande();
                        Thread tsg = new Thread(SG);
                        tsg.start();
                        try {
                            tsg.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                }
                return false;
            }
        });

        ProtecteurDroite.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.DP) {
                            ProtecteurDroite.setBackgroundResource(R.drawable.droite_protecteur_allume);
                            Joueur.DP = true;
                            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " 7 1");
                            EnvoieCommande G = new EnvoieCommande();
                            Thread tg = new Thread(G);
                            tg.start();
                            try {
                                tg.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        ProtecteurDroite.setBackgroundResource(R.drawable.droite_protecteur);
                        Joueur.DP = false;
                        Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -7 0");
                        EnvoieCommande SG = new EnvoieCommande();
                        Thread tsg = new Thread(SG);
                        tsg.start();
                        try {
                            tsg.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                }
                return false;
            }
        });
        ConducteurSpecial.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        ConducteurSpecial.setBackgroundResource(R.drawable.special_conducteur_allume);
                        Joueur.setMessage("DEPLACEMENT "+Joueur.getNumChar()+" 20 0");
                        EnvoieCommande tir = new EnvoieCommande();
                        Thread t = new Thread(tir);
                        t.start();
                        try {
                            t.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        ConducteurSpecial.setBackgroundResource(R.drawable.special_conducteur);
                        return true;
                }
                return false;
            }
        });

        TireurSpecial.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        TireurSpecial.setBackgroundResource(R.drawable.special_tirreur_allume);
                        Joueur.setMessage("DEPLACEMENT "+Joueur.getNumChar()+" 21 0");
                        EnvoieCommande tir = new EnvoieCommande();
                        Thread t = new Thread(tir);
                        t.start();
                        try {
                            t.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        TireurSpecial.setBackgroundResource(R.drawable.special_tirreur);
                        return true;
                }
                return false;
            }
        });

        ProtecteurSpecial.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        ProtecteurSpecial.setBackgroundResource(R.drawable.special_protecteur_allume);
                        Joueur.setMessage("DEPLACEMENT "+Joueur.getNumChar()+" 22 0");
                        EnvoieCommande tir = new EnvoieCommande();
                        Thread t = new Thread(tir);
                        t.start();
                        try {
                            t.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        ProtecteurSpecial.setBackgroundResource(R.drawable.special_protecteur);
                        return true;
                }
                return false;
            }
        });

        Protection.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        if(!Joueur.P) {
                            Protection.setBackgroundResource(R.drawable.protection_protecteur_allume);
                            Joueur.P = true;
                            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " 11 0");
                            Thread P = new Thread(new EnvoieCommande());
                            P.start();
                            try {
                                P.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        Protection.setBackgroundResource(R.drawable.protection_protecteur);
                        Joueur.P = false;
                        Joueur.setMessage("DEPLACEMENT  "+ Joueur.getNumChar() +" 12 0");
                        Thread SP = new Thread(new EnvoieCommande());
                        SP.start();
                        try {
                            SP.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                }
                return false;
            }
        });
    }
    class Attente implements Runnable{
        String[] rep;
        @Override
        public void run() {
            try {

                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                InputStream in  = Joueur.getSocket().getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                String msg = reader.readLine();
                rep = msg.split(" ");
                Log.d("affichage", "Attente reception de "+msg);
                if(rep[0].equals("NEW_BUTT")){
                    v.vibrate(400);
                    reinit();//si jamais le changement de bouton vient lorsque le joueur est en train d'appuyer
                    for(String var: rep){
                        switch (var){
                            case "F":
                                Log.d("affichage", "changement de "+var);
                                Joueur.Feu = true;

                                Joueur.Protection = false;
                                Joueur.ConducteurHautBas = false;
                                break;

                            case "TG":
                                Log.d("affichage", "changement de "+var);
                                Joueur.TireurGauche = true;

                                Joueur.ConducteurGauche = false;
                                Joueur.ProtecteurGauche = false;
                                break;

                            case "TD":
                                Log.d("affichage", "changement de "+var);
                                Joueur.TireurDroite = true;

                                Joueur.ConducteurDroite = false;
                                Joueur.ProtecteurDroite = false;
                                break;

                            case "TS":
                                Log.d("affichage", "changement de "+var);
                                Joueur.TireurSpecial = true;

                                Joueur.ConducteurSpecial = false;
                                Joueur.ProtecteurSpecial = false;
                                break;

                            case "P":
                                Log.d("affichage", "changement de "+var);
                                Joueur.Protection = true;

                                Joueur.Feu = false;
                                Joueur.ConducteurHautBas = false;
                                break;

                            case "PG":
                                Log.d("affichage", "changement de "+var);
                                Joueur.ProtecteurGauche = true;

                                Joueur.ConducteurGauche = false;
                                Joueur.TireurGauche = false;
                                break;

                            case "PD":
                                Log.d("affichage", "changement de "+var);
                                Joueur.ProtecteurDroite = true;

                                Joueur.ConducteurDroite = false;
                                Joueur.TireurDroite = false;
                                break;

                            case "PS":
                                Log.d("affichage", "changement de "+var);
                                Joueur.ProtecteurSpecial = true;

                                Joueur.TireurSpecial = false;
                                Joueur.ConducteurSpecial = false;
                                break;

                            case "AR":
                                Log.d("affichage", "changement de "+var);
                                Joueur.ConducteurHautBas = true;

                                Joueur.Feu = false;
                                Joueur.Protection = false;
                                break;

                            case "CG":
                                Log.d("affichage", "changement de "+var);
                                Joueur.ConducteurGauche = true;

                                Joueur.ProtecteurGauche = false;
                                Joueur.TireurGauche = false;
                                break;

                            case "CD":
                                Log.d("affichage", "changement de "+var);
                                Joueur.ConducteurDroite = true;

                                Joueur.TireurDroite = false;
                                Joueur.ProtecteurDroite = false;
                                break;

                            case "CS":
                                Log.d("affichage", "changement de "+var);
                                Joueur.ConducteurSpecial = true;

                                Joueur.TireurSpecial = false;
                                Joueur.ProtecteurSpecial =false;
                                break;
                        }
                    }
                    Log.d("affichage", "lancement nouvelle activité");
                    startActivity(new Intent(Manette.this, Manette.class).addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION));
                    finish();
                }else {
                    //le joueur vient de mourir ou utime ready
                    startActivity(new Intent(Manette.this, Mort.class));
                    finish();
                }
            } catch (IOException e1) {
                e1.printStackTrace();
            }

        }
    }


    private void chargerBouton(){
        //Conducteur
        if(Joueur.ConducteurGauche)
            ConducteurGauche.setVisibility(View.VISIBLE);
        if(Joueur.ConducteurDroite)
            ConducteurDroite.setVisibility(View.VISIBLE);
        if(Joueur.ConducteurHautBas){
            Haut.setVisibility(View.VISIBLE);
            Bas.setVisibility(View.VISIBLE);
        }
        if(Joueur.ConducteurSpecial)
            ConducteurSpecial.setVisibility(View.VISIBLE);

        //Tireur
        if(Joueur.TireurSpecial)
            TireurSpecial.setVisibility(View.VISIBLE);
        if(Joueur.TireurGauche)
            TireurGauche.setVisibility(View.VISIBLE);
        if(Joueur.TireurDroite)
            TireurDroite.setVisibility(View.VISIBLE);
        if(Joueur.Feu)
            Feu.setVisibility(View.VISIBLE);

        //Protecteur
        if(Joueur.Protection)
            Protection.setVisibility(View.VISIBLE);
        if(Joueur.ProtecteurGauche)
            ProtecteurGauche.setVisibility(View.VISIBLE);
        if(Joueur.ProtecteurDroite)
            ProtecteurDroite.setVisibility(View.VISIBLE);
        if(Joueur.ProtecteurSpecial)
            ProtecteurSpecial.setVisibility(View.VISIBLE);
    }

    private void reinit(){//ajustement des requete si changement de manette alors que boutons enfoncé
        if(Joueur.DC) {
            Joueur.DC = false;
            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -3 0");
            EnvoieCommande SG = new EnvoieCommande();
            Thread tsg = new Thread(SG);
            tsg.start();
            try {
                tsg.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if (Joueur.GC){
            Joueur.GC = false;
            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -4 0");
            EnvoieCommande SG = new EnvoieCommande();
            Thread tsg = new Thread(SG);
            tsg.start();
            try {
                tsg.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if(Joueur.HC){
            Joueur.HC= false;
            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -1 0");
            EnvoieCommande SG = new EnvoieCommande();
            Thread tsg = new Thread(SG);
            tsg.start();
            try {
                tsg.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if(Joueur.BC){
            Joueur.BC= false;
            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -2 0");
            EnvoieCommande SG = new EnvoieCommande();
            Thread tsg = new Thread(SG);
            tsg.start();
            try {
                tsg.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if(Joueur.GP){
            Joueur.GP= false;
            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -8 0");
            EnvoieCommande SG = new EnvoieCommande();
            Thread tsg = new Thread(SG);
            tsg.start();
            try {
                tsg.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if(Joueur.DP){
            Joueur.DP= false;
            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -7 0");
            EnvoieCommande SG = new EnvoieCommande();
            Thread tsg = new Thread(SG);
            tsg.start();
            try {
                tsg.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if(Joueur.P){
            Joueur.P= false;
            Joueur.setMessage("DEPLACEMENT  "+ Joueur.getNumChar() +" 12 0");
            Thread SP = new Thread(new EnvoieCommande());
            SP.start();
            try {
                SP.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if(Joueur.DT){
            Joueur.DT= false;
            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -5 0");
            EnvoieCommande SG = new EnvoieCommande();
            Thread tsg = new Thread(SG);
            tsg.start();
            try {
                tsg.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if(Joueur.GT){
            Joueur.GT= false;
            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -6 0");
            EnvoieCommande SG = new EnvoieCommande();
            Thread tsg = new Thread(SG);
            tsg.start();
            try {
                tsg.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    @Override
    public void onBackPressed(){

    }


}
