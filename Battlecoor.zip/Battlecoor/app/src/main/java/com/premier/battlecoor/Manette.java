package com.premier.battlecoor;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Manette extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.manette);

        //Declaration des boutons
        //Conducteur
        final Button ConducteurGauche = findViewById(R.id.CG);
        final Button ConducteurDroite = findViewById(R.id.CD);
        final Button Haut = findViewById(R.id.Haut);
        final Button Bas = findViewById(R.id.Bas);
        final Button ConducteurSpecial = findViewById(R.id.SC);

        //Tireur
        final Button TireurGauche = findViewById(R.id.TG);
        final Button TireurDroite = findViewById(R.id.TD);
        final Button Feu = findViewById(R.id.FEU);
        final Button TireurSpecial = findViewById(R.id.ST);


        final Button ProtecteurGauche = findViewById(R.id.PG);
        final Button ProtecteurDroite = findViewById(R.id.PD);
        final Button Protection = findViewById(R.id.PROTECTION);
        final Button ProtecteurSpecial = findViewById(R.id.SP);

        class Attente implements Runnable{
            String rep[];
            @Override
            public void run() {
                try {
                    InputStream in  = Joueur.getSocket().getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    rep = reader.readLine().split(" ");
                    while ((!rep.equals("NEW_BUTT")) || (Joueur.changerButtons == false)){
                        rep = reader.readLine().split(" ");
                    }
                    Joueur.changerButtons = false;
                    //TODO changement des boutons
                    for(int i=1; i<=4; i++){
                        switch (rep[i]){
                            case "F":
                                Feu.setVisibility(View.VISIBLE);

                                Haut.setVisibility(View.INVISIBLE);
                                Bas.setVisibility(View.INVISIBLE);
                                Protection.setVisibility(View.INVISIBLE);
                                break;

                            case "TG":
                                TireurGauche.setVisibility(View.VISIBLE);

                                ConducteurGauche.setVisibility(View.INVISIBLE);
                                ProtecteurGauche.setVisibility(View.INVISIBLE);
                                break;

                            case "TD":
                                TireurDroite.setVisibility(View.VISIBLE);

                                ConducteurDroite.setVisibility(View.INVISIBLE);
                                ProtecteurDroite.setVisibility(View.INVISIBLE);
                                break;

                            case "TS":
                                TireurSpecial.setVisibility(View.VISIBLE);

                                ConducteurSpecial.setVisibility(View.INVISIBLE);
                                ProtecteurSpecial.setVisibility(View.INVISIBLE);
                                break;

                            case "P":
                                Protection.setVisibility(View.VISIBLE);

                                Feu.setVisibility(View.INVISIBLE);
                                Haut.setVisibility(View.INVISIBLE);
                                Bas.setVisibility(View.INVISIBLE);
                                break;

                            case "PG":
                                ProtecteurGauche.setVisibility(View.VISIBLE);

                                TireurGauche.setVisibility(View.INVISIBLE);
                                ConducteurGauche.setVisibility(View.INVISIBLE);
                                break;

                            case "PD":
                                ProtecteurDroite.setVisibility(View.VISIBLE);

                                TireurDroite.setVisibility(View.INVISIBLE);
                                ConducteurDroite.setVisibility(View.INVISIBLE);
                                break;

                            case "PS":
                                ProtecteurSpecial.setVisibility(View.VISIBLE);

                                ConducteurSpecial.setVisibility(View.INVISIBLE);
                                TireurSpecial.setVisibility(View.INVISIBLE);
                                break;

                            case "AR":
                                Haut.setVisibility(View.VISIBLE);

                                Feu.setVisibility(View.INVISIBLE);
                                Protection.setVisibility(View.INVISIBLE);
                                break;

                            case "CG":
                                ConducteurGauche.setVisibility(View.VISIBLE);

                                TireurGauche.setVisibility(View.INVISIBLE);
                                ProtecteurGauche.setVisibility(View.INVISIBLE);
                                break;

                            case "CD":
                                ConducteurDroite.setVisibility(View.VISIBLE);

                                TireurDroite.setVisibility(View.INVISIBLE);
                                ProtecteurGauche.setVisibility(View.INVISIBLE);
                                break;

                            case "CS":
                                ConducteurSpecial.setVisibility(View.VISIBLE);

                                TireurSpecial.setVisibility(View.INVISIBLE);
                                ProtecteurSpecial.setVisibility(View.INVISIBLE);
                                break;

                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        switch (Joueur.getRole()) {
            case "Conducteur":
                ConducteurGauche.setVisibility(View.VISIBLE);
                ConducteurDroite.setVisibility(View.VISIBLE);
                Haut.setVisibility(View.VISIBLE);
                Bas.setVisibility(View.VISIBLE);
                ConducteurSpecial.setVisibility(View.VISIBLE);
                break;
            case "Tireur":
                TireurGauche.setVisibility(View.VISIBLE);
                TireurDroite.setVisibility(View.VISIBLE);
                Feu.setVisibility(View.VISIBLE);
                TireurSpecial.setVisibility(View.VISIBLE);
                break;
            case "Protecteur":
                ProtecteurGauche.setVisibility(View.VISIBLE);
                ProtecteurDroite.setVisibility(View.VISIBLE);
                Protection.setVisibility(View.VISIBLE);
                ProtecteurSpecial.setVisibility(View.VISIBLE);
                break;
        }

        //ACTION A REALISER
        ConducteurGauche.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.GC) {
                            ConducteurGauche.setBackgroundResource(R.drawable.gauche_conducteur_allume);
                            Joueur.GC = true;
                            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " 4 1");
                            EnvoieCommande G = new EnvoieCommande();
                            Thread tg = new Thread(G);
                            tg.start();
                            try {
                                tg.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        ConducteurGauche.setBackgroundResource(R.drawable.gauche_conducteur);
                        Joueur.GC = false;
                        Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -4 0");
                        EnvoieCommande SG = new EnvoieCommande();
                        Thread tsg = new Thread(SG);
                        tsg.start();
                        try {
                            tsg.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                }
                return false;
            }
        });

        ConducteurDroite.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.DC) {
                            ConducteurDroite.setBackgroundResource(R.drawable.droite_conducteur_allume);
                            Joueur.DC = true;
                            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " 3 1");
                            EnvoieCommande G = new EnvoieCommande();
                            Thread tg = new Thread(G);
                            tg.start();
                            try {
                                tg.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        ConducteurDroite.setBackgroundResource(R.drawable.droite_conducteur);
                        Joueur.DC = false;
                        Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -3 0");
                        EnvoieCommande SG = new EnvoieCommande();
                        Thread tsg = new Thread(SG);
                        tsg.start();
                        try {
                            tsg.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                }
                return false;
            }
        });

        Haut.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.HC) {
                            Haut.setBackgroundResource(R.drawable.haut_conducteur_allume);
                            Joueur.HC = true;
                            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " 1 1");
                            EnvoieCommande G = new EnvoieCommande();
                            Thread tg = new Thread(G);
                            tg.start();
                            try {
                                tg.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:

                        Joueur.HC = false;
                        Haut.setBackgroundResource(R.drawable.haut_conducteur);
                        Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -1 0");
                        EnvoieCommande SG = new EnvoieCommande();
                        Thread tsg = new Thread(SG);
                        tsg.start();
                        try {
                            tsg.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                }
                return false;
            }
        });

        Bas.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.BC) {
                            Bas.setBackgroundResource(R.drawable.bas_conducteur_allume);
                            Joueur.BC = true;
                            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " 2 1");
                            EnvoieCommande G = new EnvoieCommande();
                            Thread tg = new Thread(G);
                            tg.start();
                            try {
                                tg.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        Bas.setBackgroundResource(R.drawable.bas_conducteur);
                        Joueur.BC = false;
                        Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -2 0");
                        EnvoieCommande SG = new EnvoieCommande();
                        Thread tsg = new Thread(SG);
                        tsg.start();
                        try {
                            tsg.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                }
                return false;
            }
        });

        TireurGauche.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.GT) {
                            TireurGauche.setBackgroundResource(R.drawable.gauche_tirreur_allume);
                            Joueur.GT = true;
                            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " 6 1");
                            EnvoieCommande G = new EnvoieCommande();
                            Thread tg = new Thread(G);
                            tg.start();
                            try {
                                tg.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        TireurGauche.setBackgroundResource(R.drawable.gauche_tirreur);
                        Joueur.GT = false;
                        Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -6 0");
                        EnvoieCommande SG = new EnvoieCommande();
                        Thread tsg = new Thread(SG);
                        tsg.start();
                        try {
                            tsg.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                }
                return false;
            }
        });

        TireurDroite.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.DT) {
                            TireurDroite.setBackgroundResource(R.drawable.droite_tirreur_allume);
                            Joueur.DT = true;
                            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " 5 1");
                            EnvoieCommande G = new EnvoieCommande();
                            Thread tg = new Thread(G);
                            tg.start();
                            try {
                                tg.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        TireurDroite.setBackgroundResource(R.drawable.droite_tirreur);
                        Joueur.DT = false;
                        Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -5 0");
                        EnvoieCommande SG = new EnvoieCommande();
                        Thread tsg = new Thread(SG);
                        tsg.start();
                        try {
                            tsg.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                }
                return false;
            }
        });


        Feu.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        Feu.setBackgroundResource(R.drawable.tirer_tirreur_allume);
                        Joueur.setMessage("TIR " + Joueur.getNumChar() + " 0");
                        EnvoieCommande tir = new EnvoieCommande();
                        Thread t = new Thread(tir);
                        t.start();
                        try {
                            t.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        Feu.setBackgroundResource(R.drawable.tirer_tirreur);
                        return true;
                }
                return false;
            }
        });
        ProtecteurGauche.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.GP) {
                            ProtecteurGauche.setBackgroundResource(R.drawable.gauche_protecteur_allume);
                            Joueur.GP = true;
                            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " 8 1");
                            EnvoieCommande G = new EnvoieCommande();
                            Thread tg = new Thread(G);
                            tg.start();
                            try {
                                tg.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        ProtecteurGauche.setBackgroundResource(R.drawable.gauche_protecteur);
                        Joueur.GP = false;
                        Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -8 0");
                        EnvoieCommande SG = new EnvoieCommande();
                        Thread tsg = new Thread(SG);
                        tsg.start();
                        try {
                            tsg.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                }
                return false;
            }
        });

        ProtecteurDroite.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!Joueur.DP) {
                            ProtecteurDroite.setBackgroundResource(R.drawable.droite_protecteur_allume);
                            Joueur.DP = true;
                            Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " 7 1");
                            EnvoieCommande G = new EnvoieCommande();
                            Thread tg = new Thread(G);
                            tg.start();
                            try {
                                tg.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        ProtecteurDroite.setBackgroundResource(R.drawable.droite_protecteur);
                        Joueur.DP = false;
                        Joueur.setMessage("DEPLACEMENT " + Joueur.getNumChar() + " -7 0");
                        EnvoieCommande SG = new EnvoieCommande();
                        Thread tsg = new Thread(SG);
                        tsg.start();
                        try {
                            tsg.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                }
                return false;
            }
        });
    ConducteurSpecial.setOnTouchListener(new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()){
                case MotionEvent.ACTION_DOWN:
                    ConducteurSpecial.setBackgroundResource(R.drawable.special_conducteur_allume);
                    Joueur.setMessage("");//TODO message spéciale
                    EnvoieCommande tir = new EnvoieCommande();
                    Thread t = new Thread(tir);
                    t.start();
                    try {
                        t.join();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    ConducteurSpecial.setBackgroundResource(R.drawable.special_conducteur);
                    return true;
            }
            return false;
        }
    });

        TireurSpecial.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        TireurSpecial.setBackgroundResource(R.drawable.special_tirreur_allume);
                        Joueur.setMessage("");//TODO message spéciale
                        EnvoieCommande tir = new EnvoieCommande();
                        Thread t = new Thread(tir);
                        t.start();
                        try {
                            t.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        TireurSpecial.setBackgroundResource(R.drawable.special_tirreur);
                        return true;
                }
                return false;
            }
        });

        ProtecteurSpecial.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        ProtecteurSpecial.setBackgroundResource(R.drawable.special_protecteur_allume);
                        Joueur.setMessage("");//TODO message spéciale
                        EnvoieCommande tir = new EnvoieCommande();
                        Thread t = new Thread(tir);
                        t.start();
                        try {
                            t.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        ProtecteurSpecial.setBackgroundResource(R.drawable.special_protecteur);
                        return true;
                }
                return false;
            }
        });
    }
    @Override
    public void onBackPressed(){
    }

}
